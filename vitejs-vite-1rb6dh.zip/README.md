# Gün Projesi: Filmler Sayfası

Bugün takım olarak yeni bir işe atandınız. İlk olarak özelliklerin çalışır hale gelmesini sağlayacaksın. Daha sonra UI ekibi, yaptıklarınızın üzerine styling uygulayacak ve sayfanın final tasarıma benzemesini sağlayacak.

Sana 7 tane görev düşüyor. Görevlerden:

- İlk 3'ü App.jsx içinde  
- 2 tanesi Film.jsx'de  
- 1'er tane'de FilmDetaylari ve KaydedilenlerListesi.jsx'de.

Filmlerin listesini sahteVeri.js'den alabilirsin.
